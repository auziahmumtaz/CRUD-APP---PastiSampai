import pymysql

class Database:
    def connect(self):
        return pymysql.connect(host='localhost',
                             user='admin',
                             password='1234',
                             db='pastisampai')

    def read(self, id_pengiriman):
        con = Database.connect(self)
        cursor = con.cursor()

        try:
            if id_pengiriman == None:
                cursor.execute("SELECT * FROM data_pengiriman order by id_pengiriman asc")
            else:
                cursor.execute("SELECT * FROM data_pengiriman where id_pengiriman = %s order by id_pengiriman asc", (id_pengiriman,))

            return cursor.fetchall()
        except:
            return ()
        finally:
            con.close()

    def insert(self,data):
        con = Database.connect(self)
        cursor = con.cursor()

        try:
            cursor.execute("INSERT INTO data_pengiriman(id_pengiriman, tanggal_pengiriman, jenis_pengiriman, jenis_barang, asal_pengiriman, tujuan_pengiriman, status_pengiriman) VALUES (%s, %s, %s, %s, %s, %s, %s)", (data['id_pengiriman'],data['tanggal_pengiriman'],data['jenis_pengiriman'],data['jenis_barang'],data['asal_pengiriman'],data['tujuan_pengiriman'],data['status_pengiriman']))
            con.commit()

            return True
        except:
            con.rollback()

            return False
        finally:
            con.close()

    def update(self, id_pengiriman, data):
        con = Database.connect(self)
        cursor = con.cursor()

        try:
            cursor.execute("UPDATE data_pengiriman set tanggal_pengiriman = %s, jenis_pengiriman = %s, jenis_barang = %s, asal_pengiriman = %s, tujuan_pengiriman = %s, tujuan_pengiriman = %s where id_pengiriman = %s", (data['tanggal_pengiriman'],data['jenis_pengiriman'],data['jenis_barang'],data['asal_pengiriman'],data['tujuan_pengiriman'],data['status_pengiriman'],id_pengiriman,))
            con.commit()

            return True
        except:
            con.rollback()

            return False
        finally:
            con.close()

    def delete(self, id_pengiriman):
        con = Database.connect(self)
        cursor = con.cursor()

        try:
            cursor.execute("DELETE FROM data_pengiriman where id_pengiriman = %s", (id_pengiriman,))
            con.commit()

            return True
        except:
            con.rollback()

            return False
        finally:
            con.close()