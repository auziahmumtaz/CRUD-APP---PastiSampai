
import os
from flask import Flask, flash, render_template, redirect, url_for, request, session
from database import Database


app = Flask(__name__)
app.secret_key = os.urandom(12)
db = Database()

@app.route('/')
def index():
    data = db.read(None)

    return render_template('index.html', data = data)

@app.route('/add/')
def add():
    return render_template('add.html')

@app.route('/addstatus', methods = ['POST', 'GET'])
def addstatus():
    if request.method == 'POST' and request.form['save']:
        if db.insert(request.form):
            flash("Status telah diperbarui")
        else:
            flash("Status tidak dapat diperbarui")

        return redirect(url_for('index'))
    else:
        return redirect(url_for('index'))

@app.route('/update/<int:id_pengiriman>/')
def update(id_pengiriman):
    data = db.read(id_pengiriman);

    if len(data) == 0:
        return redirect(url_for('index'))
    else:
        session['update'] = id_pengiriman
        return render_template('update.html', data = data)

@app.route('/updatestatus', methods = ['POST'])
def updatestatus():
    if request.method == 'POST' and request.form['update']:

        if db.update(session['update'], request.form):
            flash('Status telah diperbarui')

        else:
            flash('Status tidak dapat diperbarui')

        session.pop('update', None)

        return redirect(url_for('index'))
    else:
        return redirect(url_for('index'))

@app.route('/delete/<int:id_pengiriman>/')
def delete(id_pengiriman):
    data = db.read(id_pengiriman);

    if len(data) == 0:
        return redirect(url_for('index'))
    else:
        session['delete'] = id_pengiriman
        return render_template('delete.html', data = data)

@app.route('/deletestatus', methods = ['POST'])
def deletestatus():
    if request.method == 'POST' and request.form['delete']:

        if db.delete(session['delete']):
            flash('Status telah dihapus')

        else:
            flash('Status tidak dapat dihapus')

        session.pop('delete', None)

        return redirect(url_for('index'))
    else:
        return redirect(url_for('index'))

@app.errorhandler(404)
def page_not_found(error):
    return render_template('error.html')

if __name__ == '__main__':
    app.run(debug=True)
