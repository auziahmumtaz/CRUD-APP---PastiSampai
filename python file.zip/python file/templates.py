#!/usr/bin/env python
# coding: utf-8

# In[1]:


from IPython.display import HTML

HTML(filename="add.html")


# In[3]:


from IPython.display import HTML

HTML(filename="delete.html")


# In[4]:


from IPython.display import HTML

HTML(filename="error.html")


# In[ ]:





# In[5]:


from IPython.display import HTML

HTML(filename="index.html")


# In[6]:


from IPython.display import HTML

HTML(filename="update.html")

